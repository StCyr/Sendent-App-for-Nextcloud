<?php

namespace OCA\Sendent\Service;

use Exception;

class ServiceException extends Exception {
}
