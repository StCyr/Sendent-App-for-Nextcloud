<?php

namespace OCA\Sendent\Service;

use Exception;

class StorageException extends Exception {
}
