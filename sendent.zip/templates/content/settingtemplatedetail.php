<p>settingTemplateDetail</p>
<?php
script('sendent', ['script']);
script('sendent', ['SettingTemplateScript2']);
?>