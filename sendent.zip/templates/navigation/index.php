<ul>
	<li><a href="#">Manage settings</a></li>
</ul>
