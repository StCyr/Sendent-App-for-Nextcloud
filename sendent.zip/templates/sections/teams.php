<div id="talk">
    <h1>
        <?php p($l->t('General')); ?>
    </h1>
    <p><?php p($l->t('Upon the next release of the Sendent for MS Teams integration, which will be coming soon, this page will contain settings.')); ?></p>
</div>