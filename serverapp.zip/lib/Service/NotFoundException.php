<?php

namespace OCA\Sendent\Service;

class NotFoundException extends ServiceException {
}
