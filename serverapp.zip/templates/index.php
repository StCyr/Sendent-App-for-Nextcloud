
<?php print_unescaped($this->inc('content/index')); ?>
